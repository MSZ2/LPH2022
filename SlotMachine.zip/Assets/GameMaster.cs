using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using System;

public class GameMaster : MonoBehaviour
{
    [SerializeField]
    private UnityEvent startSpin;

    [SerializeField]
    private Reel[] reels;

    [SerializeField]
    private Text fundsText;

    [SerializeField]
    private GameObject inputField; 

    //[SerializeField]
    //private Button spinButton;

    private bool[] finished = {true, true, true};

    private int winnings = 0;
    private int funds = 10;
    private bool spinning = false;
    private System.Random rnd = new System.Random();

    // Start is called before the first frame update
    void Start()
    {
        fundsText.GetComponent<Text>().text = funds.ToString();
    }

    public void spinClick() {
        if (!spinning) {
            //int bet = int.Parse(inputField.GetComponent<Text>().text);
            int bet = 1;
            if (bet > funds) return;
            funds -= bet;
            spinning = true;
            int[] ind = { rnd.Next(0, 16), rnd.Next(0, 16), rnd.Next(0, 16) };
            
            setDest(ind);
            startSpin.Invoke();
            finished[0] = finished[1] = finished[2] = false;

            if (reels[0].symbols[ind[0]] == reels[1].symbols[ind[1]] && reels[1].symbols[ind[1]] == reels[2].symbols[ind[2]])
            {
                switch (reels[0].symbols[ind[0]])
                {
                    case 2:
                        winnings += 10 * bet;
                        break;
                    case 3:
                        winnings += 20 * bet;
                        break;
                    case 4:
                        winnings += 30 * bet;
                        break;
                    case 5:
                    case 6:
                        winnings += 40 * bet;
                        break;
                    case 1:
                        winnings += 100 * bet;
                        break;
                }
            }
            else
            {
                int cnt = (reels[0].symbols[ind[0]] == 1 ? 1 : 0) + (reels[1].symbols[ind[1]] == 1 ? 1 : 0) + (reels[2].symbols[ind[2]] == 1 ? 1 : 0);
                if (cnt == 2) winnings += 5 * bet;
                else if (cnt == 1) winnings += 1 * bet;
            }

            
            
        }
    }

    public void finish1() {finished[0] = true;}
    public void finish2() {finished[1] = true;}
    public void finish3() {finished[2] = true;}


    void setDest(int[] ind) {
        reels[0].dest = ind[0];
        reels[1].dest = ind[1];
        reels[2].dest = ind[2];
    }

    // Update is called once per frame
    void Update()
    {
        if (finished[0] == true && finished[1] == true && finished[2] == true && spinning == true) {
            funds += winnings;
            winnings = 0;
            spinning = false;
            fundsText.GetComponent<Text>().text = funds.ToString();
        }
    }
}
