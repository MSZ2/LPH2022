using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


/*
ID  NAME
1   Gustavo
2   Sombrero
3   Batak
4   Kofica
5   Petao
6   Kokska
 */


public class Reel : MonoBehaviour
{
    [SerializeField]
    public int [] symbols;

    [SerializeField]
    private UnityEvent finishSpin;

    public int dest;

    private bool spinning = false;
    private float interval;
    protected int limit = 0;

    // Start is called before the first frame update
    void Start()
    {
        limit = 0;
    }

    public void startSpinning() {
        if (!spinning) StartCoroutine("spin");
    }

    private IEnumerator spin() {
        spinning = true;
        interval = 0.025f;

        for (int i = 0; i < 49 - limit; i++) {

            if (transform.position.y >= 11.5f) 
                transform.position = new Vector2(transform.position.x, -0.5f);

            transform.position = new Vector2(transform.position.x, transform.position.y + 0.25f);

            yield return new WaitForSeconds(interval);
        }

        limit = 0;
        switch(symbols[dest]){
            case 1: //Gustavo
                limit = 10*4;
                break;
            case 2: //Sombrero
                limit = 2*4;
                break;
            case 3: //Batak
                limit = 6*4;
                break;
            case 4: //Kofica
                limit = 4*4;
                break;
            case 5: //Petao
                limit = 12*4;
                break;
            case 6: //Kokoska
                limit = 8*4;
                break;
        }

        for (int i = 0; i < limit-1; i++) {

            if (transform.position.y >= 11.5f) 
                transform.position = new Vector2(transform.position.x, -0.5f);

            transform.position = new Vector2(transform.position.x, transform.position.y + 0.25f);

            yield return new WaitForSeconds(interval);
        }

        spinning = false;
        finishSpin.Invoke();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
